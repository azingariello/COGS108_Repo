
# Section_Workbooks
Workbooks in this repo are to be used during discussion section as another way in which students can get extra practice with course concepts and Python programming. 

## Discussion Section

For use in discussion section, each workbook is broken down into three parts so that instructional staff can review each part over the course of the discussion section. 

Sometimes these are designed to help you better understand what you'll need to do for your assignments. Often you will be walked through an analysis step by step. However, in other cases, these will include less guidance and it's up to you to figure out what code must be written to accomplish the task / analyze the dataset.

 
